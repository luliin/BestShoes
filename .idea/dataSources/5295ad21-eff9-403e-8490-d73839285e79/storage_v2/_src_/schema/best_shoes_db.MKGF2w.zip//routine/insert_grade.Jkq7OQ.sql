create
    definer = julia@localhost procedure insert_grade(IN _grade varchar(50), IN _score int)
BEGIN
    insert into grades(grade, score)
    values (_grade, _score);
END;

