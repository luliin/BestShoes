create
    definer = julia@localhost function average_grade(_item_id int) returns float
begin
    declare average float;
    select avg(grades.score) from reviews
                                      left join grades using(grade_id) where _item_id = item_id
    group by item_id into average;
    return average;
end;

