create
    definer = julia@localhost procedure insert_product_category(IN _type varchar(50))
BEGIN
	insert into product_catetegories(type) values (_type);
END;

