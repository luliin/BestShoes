create definer = julia@localhost view average_grades as
select `best_shoes_db`.`items`.`item_name`                                      AS `Produkt`,
       avg(`g1`.`score`)                                                        AS `Medel (numeriskt)`,
       (select `best_shoes_db`.`grades`.`grade`
        from `best_shoes_db`.`grades`
        where (`best_shoes_db`.`grades`.`score` = round(avg(`g1`.`score`), 0))) AS `Medel (text)`
from (`best_shoes_db`.`items`
         left join (`best_shoes_db`.`reviews` left join `best_shoes_db`.`grades` `g1` on ((`best_shoes_db`.`reviews`.`grade_id` = `g1`.`grade_id`)))
                   on ((`best_shoes_db`.`items`.`item_id` = `best_shoes_db`.`reviews`.`item_id`)))
group by `best_shoes_db`.`items`.`item_id`;

