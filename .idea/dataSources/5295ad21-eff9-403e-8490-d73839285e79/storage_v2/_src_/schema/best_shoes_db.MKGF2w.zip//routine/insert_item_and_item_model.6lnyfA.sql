create
    definer = julia@localhost procedure insert_item_and_item_model(IN _item_name varchar(50), IN _brand_id int,
                                                                   IN _product_category_id int, IN _size varchar(20),
                                                                   IN _color_id int, IN _price float)
BEGIN
    declare error_message varchar(100) default 'An unexpected error has occurred. Rollback executed';
    declare current_item int;
    declare current_item_model int;
    declare unexpected_error condition for sqlstate '45000';

    declare exit handler for sqlexception
        begin
            rollback;
            resignal unexpected_error set message_text = error_message;
        end;

    select item_id from items where item_name = _item_name into current_item;


    set autocommit = false;
        if current_item is null then
            insert into items(item_name, brand_id, product_category_id) values
            (_item_name, _brand_id, _product_category_id);

            insert into item_models(item_id, size, color_id, price) values
            (last_insert_id(), _size, _color_id, _price);
        else
            select item_model_id from item_models where item_id = current_item
            and size = _size and price = _price and color_id = _color_id into current_item_model;
            if current_item_model is null then
                insert into item_models(item_id, size, color_id, price) values
                (current_item, _size, _color_id, _price);
            else
                update item_models set quantity = (quantity+1) where item_model_id = current_item_model;
            end if;
        end if;
        commit;
    set autocommit = true;
END;

