create
    definer = julia@localhost procedure rate(IN _customer_id int, IN _item_id int, IN _grade_id int,
                                             IN _comment varchar(1000))
begin
        insert into reviews (customer_id, item_id, grade_id, comment) values (_customer_id, _item_id, _grade_id, _comment);
    end;

