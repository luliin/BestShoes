create definer = julia@localhost trigger before_update_line_order_cost
    before update
    on line_items
    for each row
begin
	SET new.line_cost = 
		(SELECT item_models.price * NEW.quantity FROM item_models
		WHERE item_model_id = NEW.item_model_id
		LIMIT 1);
      
end;

