create
    definer = julia@localhost procedure insert_subcategory(IN _type varchar(50))
BEGIN
    insert into subcategories(type) values (_type);
END;

