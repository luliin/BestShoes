create
    definer = julia@localhost procedure add_to_cart(IN _customer_id int, IN _order_id int, IN _item_model_id int,
                                                    OUT _current_order_id int)
BEGIN

    declare unexpected_error CONDITION FOR SQLSTATE '45000';

    declare current_customer int;
    declare current_order int;
    declare current_item_model int;
    declare current_line_item int;
    declare error_message varchar(100) default 'An unexpected error has occurred.';

    declare exit handler for sqlexception
        begin
            ROLLBACK;
            RESIGNAL unexpected_error set MESSAGE_TEXT = error_message;
        end;

    set autocommit = false;
    start transaction;

    select customer_id from customers where customer_id = _customer_id into current_customer;
    select order_id from orders where order_id = _order_id into current_order;
    select item_model_id from item_models where item_model_id = _item_model_id into current_item_model;
    select line_item_id from line_items where order_id = current_order and item_model_id = current_item_model into current_line_item;

    set _current_order_id = current_order;

    if current_customer is not null and current_item_model is not null then
        if current_order is null then
            insert into orders(customer_id) values (current_customer);
            set _current_order_id = last_insert_id();
            insert into line_items(order_id, item_model_id) values (last_insert_id(), current_item_model);
        elseif current_line_item is null then
            insert into line_items(order_id, item_model_id) values (current_order, current_item_model);
        else
            update line_items set quantity = quantity+1 where line_item_id = current_line_item;
        end if;
    elseif current_customer is null and current_item_model is null then
        set error_message = 'Wrong customer id and item model id';
        signal unexpected_error;
    elseif current_customer is null then
        set error_message = 'Wrong customer id';
        signal unexpected_error;
    else
        set error_message = 'Wrong item model id';
        signal unexpected_error;
    END if;
    commit;
    set autocommit = true;
end;

