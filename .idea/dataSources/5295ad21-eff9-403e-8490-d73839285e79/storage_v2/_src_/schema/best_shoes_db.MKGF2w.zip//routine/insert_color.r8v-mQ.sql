create
    definer = julia@localhost procedure insert_color(IN name varchar(50))
BEGIN
     insert into colors(color) values (name);
END;

