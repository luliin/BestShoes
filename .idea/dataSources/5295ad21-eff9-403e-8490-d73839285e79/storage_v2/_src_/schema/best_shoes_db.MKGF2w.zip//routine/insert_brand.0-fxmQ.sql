create
    definer = julia@localhost procedure insert_brand(IN name varchar(50))
BEGIN
	if name not in (select brand_name from brands) then
	insert into brands(brand_name) values (name);
    end if;
END;

