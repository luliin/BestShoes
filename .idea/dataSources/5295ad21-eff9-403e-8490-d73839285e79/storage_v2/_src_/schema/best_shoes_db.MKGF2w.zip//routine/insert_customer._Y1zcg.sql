create
    definer = julia@localhost procedure insert_customer(IN _short_name varchar(50), IN _full_name varchar(150),
                                                        IN _personal_number varchar(20), IN _phone_number varchar(20),
                                                        IN _email varchar(100), IN _street_address varchar(100),
                                                        IN _zip_code varchar(10), IN _city varchar(50),
                                                        IN _password varchar(50))
BEGIN
     insert into customers(short_name, full_name, personal_number, phone_number, email, street_address, zip_code, city, password)
     values (_short_name, _full_name, _personal_number, _phone_number, _email, _street_address, _zip_code, _city, _password);
END;

