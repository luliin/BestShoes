create definer = julia@localhost view grade_with_comment as
select `best_shoes_db`.`reviews`.`item_id` AS `item_id`,
       `best_shoes_db`.`grades`.`grade`    AS `grade`,
       `best_shoes_db`.`reviews`.`comment` AS `comment`
from (`best_shoes_db`.`reviews`
         join `best_shoes_db`.`grades`
              on ((`best_shoes_db`.`reviews`.`grade_id` = `best_shoes_db`.`grades`.`grade_id`)));

