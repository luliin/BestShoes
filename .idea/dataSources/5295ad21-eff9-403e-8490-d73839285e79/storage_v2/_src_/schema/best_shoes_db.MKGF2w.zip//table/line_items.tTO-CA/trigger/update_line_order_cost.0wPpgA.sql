create definer = julia@localhost trigger update_line_order_cost
    before insert
    on line_items
    for each row
begin
	SET NEW.line_cost = 
		(SELECT item_models.price * NEW.quantity FROM item_models
		WHERE item_model_id = NEW.item_model_id
		LIMIT 1);
		UPDATE orders
		SET orders.total_cost = orders.total_cost + new.line_cost
		WHERE orders.order_id = NEW.order_id;
      
end;

