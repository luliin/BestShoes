create
    definer = julia@localhost procedure add_item(IN _brand varchar(50), IN _item varchar(50), IN _color varchar(50),
                                                 IN _price int, IN _min_size int, IN _max_size int,
                                                 IN _category varchar(50), OUT _item_id int)
BEGIN
    declare no_such_category CONDITION FOR SQLSTATE '45000';
    declare _brand_id int;
    declare _color_id int;
    declare _check int;
    declare error_message varchar(100);
    declare exit handler for sqlexception
        begin
            ROLLBACK;
            RESIGNAL SET MESSAGE_TEXT = error_message;
        end;
    set error_message = 'Unexpected error occurred. Rollback executed.';
    if (select product_category_id from product_categories where type = _category) is null then
        set error_message = 'Category doesn''t exist';
        signal no_such_category;
    end if;
    set autocommit = 0;
    start transaction;
    select brand_id from brands where brand_name = _brand into _brand_id;
    set error_message = '_brand_id valt';
    (select item_id from items where item_name = _item and brand_id = _brand_id) into _item_id;
    set error_message = 'item_id valt';
    (select color_id from colors where color = _color) into _color_id;
    set error_message = 'color_id valt';

    if _brand_id is null then
        insert into brands(brand_name) values (_brand);
        set _brand_id = last_insert_id();
        set error_message = 'brand inserted';

    end if;
    set error_message = 'brand if passed';

    if _item_id is null then
        set error_message = 'in item if';
        insert into items(item_name, brand_id, product_category_id) values
        (_item, _brand_id, (select product_category_id from product_categories where type = _category));
        set error_message = 'item inserted';
        set _item_id = last_insert_id();
        set error_message = 'item_id set';
    end if;
    set error_message = 'item if passed';
    if _color is null then
        set _color_id = null;
    elseif _color_id is null  then
        insert into colors(color) values (_color);
        set _color_id = last_insert_id();
        set error_message = 'color inserted';
    end if;
    set error_message = 'color if passed';

    while _min_size <= _max_size  or _min_size is null do
            select count(item_id) from item_models where item_id = _item_id and color_id = _color_id into _check;
            if not exists (select * from item_models where item_id = _item_id and
                (color_id = _color_id or color_id is null) and
                (size = _min_size or size is null)) then
                begin
                    insert into item_models(item_id, color_id, size, price) values (_item_id, _color_id, _min_size, _price);
                end;
            end if;
            set _min_size = _min_size +1;
            if _min_size is null then
                set _min_size = 1;
            end if;
        end while;
    commit;
    set autocommit = 1;
END;

