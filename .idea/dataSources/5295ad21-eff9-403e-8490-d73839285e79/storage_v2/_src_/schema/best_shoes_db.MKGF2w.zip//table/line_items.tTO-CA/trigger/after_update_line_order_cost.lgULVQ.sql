create definer = julia@localhost trigger after_update_line_order_cost
    after update
    on line_items
    for each row
begin
	UPDATE orders
		SET orders.total_cost =
        (select sum(line_items.line_cost) from line_items WHERE order_id = new.order_id)
		WHERE orders.order_id = new.order_id;
      
end;

